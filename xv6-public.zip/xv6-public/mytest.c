#include "types.h"      
#include "user.h"

int main(int argc, char *argv[]) 
{ 
    printf(1, "Hey, I am trying xv6\n"); 
    exit();
}
