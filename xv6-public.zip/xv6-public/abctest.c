#include "types.h"
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
  // Keep this as 64-bit volatile to do the CPU "work"
  volatile unsigned long long i; 
  
  // Use a 32-bit counter for printing, which is fully supported
  unsigned int print_counter = 0; 
  
  char *id;

  if(argc < 2){
    printf(2, "Usage: abctest <id_char>\n");
    exit();
  }
  id = argv[1];
  
  printf(1, "Starting CPU test %s\n", id);

  for(i = 0; ; i++)
  {
    // --- THIS IS THE FIX ---
    // Increment our 32-bit counter
    print_counter++;
    
    // Check the 32-bit counter
    if (print_counter >= 10000000) {
      printf(1, "%s", id);
      print_counter = 0; // Reset the counter
    }
  }

  exit();
}
