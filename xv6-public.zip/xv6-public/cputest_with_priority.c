#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[])
{
  printf(1, "Starting CPU test...\n");

  // This volatile variable ensures the compiler doesn't optimize away our infinite loop
  volatile unsigned long long i;

  int priority = atoi(argv[1]);
  if (priority < 1 || priority > 100) {
      printf(2, "Invalid priority (1-100)\n");
      exit();
  }

  set_priority(priority);
  printf(1, "Process started with priority %d\n", priority);

  for(i = 0; ; i++)
  {
    if(i%1000 == 0){}
  }

  exit();
}
