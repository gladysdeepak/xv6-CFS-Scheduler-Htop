#ifndef UPROC_H
#define UPROC_H

struct uproc {
  int pid;        // process id
  int state;      // process state
  int rtime;      // running time ticks
  int stime;      // sleeping time ticks
  int rnbletime;     // runnable time ticks (waiting to run)
  int sz;         // memory size in bytes
  char name[16];  // process name
  int weight;                  
  long long vruntime; 
};

#endif // UPROC_H

