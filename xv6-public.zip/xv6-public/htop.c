/*#include "types.h"
#include "stat.h"
#include "user.h"

#define MAX_PROCS 64
#define REFRESH_TICKS 100


static struct uproc cur[MAX_PROCS];
static struct uproc prev[MAX_PROCS];
struct procinfo {            
  struct uproc p;
  int cpu_x10;
};
static struct procinfo arr[MAX_PROCS];

static int find_prev_index(struct uproc prev[], int pn, int pid) {
  for (int i = 0; i < pn; i++)
    if (prev[i].pid == pid) return i;
  return -1;
}

static void sort_procinfo(struct procinfo arr[], int n) {
  if (n <= 1) return;
  for (int i = 0; i < n - 1; i++) {
    for (int j = 0; j < n - i - 1; j++) {
      int swap = 0;
      if (arr[j+1].cpu_x10 > arr[j].cpu_x10) swap = 1;
      else if (arr[j+1].cpu_x10 == arr[j].cpu_x10) {
        if (arr[j+1].p.rtime > arr[j].p.rtime) swap = 1;
        else if (arr[j+1].p.rtime == arr[j].p.rtime) {
          if (arr[j+1].p.pid > arr[j].p.pid) swap = 1;
        }
      }
      if (swap) {
        struct procinfo tmp = arr[j];
        arr[j] = arr[j+1];
        arr[j+1] = tmp;
      }
    }
  }
}

static const char *state_name(int s) {
  switch (s) {
    case 0: return "UNUSED";
    case 1: return "EMBRYO";
    case 2: return "SLEEP";
    case 3: return "RUNNBL";
    case 4: return "RUN";
    case 5: return "ZOMBIE";
    default: return "????";
  }
}

int main(void) {
  int n = 0, pn = 0, first = 1;

  for (int i = 0; i < MAX_PROCS; i++) prev[i].pid = 0;

  while (1) {
    n = getprocs(cur, MAX_PROCS);
    if (n < 0) { printf(1, "getprocs failed\n"); exit(); }
    if (n > MAX_PROCS) n = MAX_PROCS; // clamp

    
    int deltas[MAX_PROCS];
    int total_delta = 0;
    for (int i = 0; i < n; i++) {
      deltas[i] = 0;
      if (!first) {
        int idx = find_prev_index(prev, pn, cur[i].pid);
        if (idx >= 0) {
          int delta_r = (int)cur[i].rtime - (int)prev[idx].rtime;
          if (delta_r < 0) delta_r = 0;
          deltas[i] = delta_r;
          total_delta += delta_r;
        }
      }
    }

    for (int i = 0; i < n; i++) {
      arr[i].p = cur[i];
      arr[i].cpu_x10 = 0;
      if (!first) {
        
        if (total_delta > 0) {
          int cpu_x10 = (deltas[i] * 1000) / total_delta; // percent * 10
          if (cpu_x10 < 0) cpu_x10 = 0;
          if (cpu_x10 > 1000) cpu_x10 = 1000;
          arr[i].cpu_x10 = cpu_x10;
        } else {
          arr[i].cpu_x10 = 0;
        }
      }
    }

    sort_procinfo(arr, n);

    // Render
    printf(1, "\x1b[2J"); 
    printf(1, "\x1b[H");
    printf(1, "PID\t STATE\t NAME\t CPU%%\t SIZE(KB)    WEIGHT\t WAIT         RUNTIME         SLEEP         VRUNTIME\n");
    printf(1, "-----------------------------------------------------------------------------------------------------------\n");

    for (int i = 0; i < n; i++) {
      struct uproc *p = &arr[i].p;
      int cpu_x10 = arr[i].cpu_x10;
      int whole = cpu_x10 / 10;
      int frac  = cpu_x10 % 10;
      int size_kb = (int)(p->sz / 1024);

      
      char namebuf[17];
      int j;
      for (j = 0; j < 16; j++) namebuf[j] = p->name[j];
      namebuf[16] = '\0';

      printf(1, "%d\t %s\t %s\t %d.%d\t     %d\t     %d\t          %d\t      %d\t      %d\t      %d\n",
             p->pid, state_name(p->state),namebuf, whole, frac,
             size_kb,p->weight,p->rnbletime,p->rtime,p->stime,p->vruntime);
    }

    
    pn = n;
    for (int i = 0; i < pn; i++) prev[i] = cur[i];
    first = 0;

    sleep(REFRESH_TICKS);
  }
  exit();
}*/
#include "types.h"
#include "stat.h"
#include "user.h"

#define MAX_PROCS 64
#define REFRESH_TICKS 100

static struct uproc cur[MAX_PROCS];
static struct uproc prev[MAX_PROCS];

struct procinfo {
  struct uproc p;
  int cpu_x10;
};
static struct procinfo arr[MAX_PROCS];


static int find_prev_index(struct uproc prev[], int pn, int pid) {
  int i;
  for (i = 0; i < pn; i++)
    if (prev[i].pid == pid) return i;
  return -1;
}

static void sort_procinfo(struct procinfo arr[], int n) {
  int i, j;
  if (n <= 1) return;
  for (i = 0; i < n - 1; i++) {
    for (j = 0; j < n - i - 1; j++) {
      int swap = 0;
      if (arr[j+1].cpu_x10 > arr[j].cpu_x10) swap = 1;
      else if (arr[j+1].cpu_x10 == arr[j].cpu_x10) {
        if (arr[j+1].p.rtime > arr[j].p.rtime) swap = 1;
        else if (arr[j+1].p.rtime == arr[j].p.rtime) {
          if (arr[j+1].p.pid > arr[j].p.pid) swap = 1;
        }
      }
      if (swap) {
        struct procinfo tmp = arr[j];
        arr[j] = arr[j+1];
        arr[j+1] = tmp;
      }
    }
  }
}

static const char *state_name(int s) {
  switch (s) {
    case 0: return "UNUSED";
    case 1: return "EMBRYO";
    case 2: return "SLEEP";
    case 3: return "RUNNBL";
    case 4: return "RUN";
    case 5: return "ZOMBIE";
    default: return "????";
  }
}


int main(void) {
  int pid = fork();

  if (pid < 0) {
    printf(1, "Fork failed\n");
    exit();
  }

  if (pid == 0) {
    int n = 0, pn = 0, first = 1;
    int i; 

    // Initialize prev array
    for (i = 0; i < MAX_PROCS; i++) prev[i].pid = 0;

    while (1) {
      n = getprocs(cur, MAX_PROCS);
      if (n < 0) { printf(1, "getprocs failed\n"); exit(); }
      if (n > MAX_PROCS) n = MAX_PROCS; // clamp
      
      int deltas[MAX_PROCS];
      int total_delta = 0;
      
      // Calculate Deltas
      for (i = 0; i < n; i++) {
        deltas[i] = 0;
        if (!first) {
          int idx = find_prev_index(prev, pn, cur[i].pid);
          if (idx >= 0) {
            int delta_r = (int)cur[i].rtime - (int)prev[idx].rtime;
            if (delta_r < 0) delta_r = 0;
            deltas[i] = delta_r;
            total_delta += delta_r;
          }
        }
      }

      // Calculate Percentages
      for (i = 0; i < n; i++) {
        arr[i].p = cur[i];
        arr[i].cpu_x10 = 0;
        if (!first) {
          if (total_delta > 0) {
            int cpu_x10 = (deltas[i] * 1000) / total_delta; // percent * 10
            if (cpu_x10 < 0) cpu_x10 = 0;
            if (cpu_x10 > 1000) cpu_x10 = 1000;
            arr[i].cpu_x10 = cpu_x10;
          } else {
            arr[i].cpu_x10 = 0;
          }
        }
      }

      sort_procinfo(arr, n);

      // Render
      printf(1, "\x1b[2J"); 
      printf(1, "\x1b[H");
     printf(1, "PID\t STATE\t NAME\t CPU%%\t SIZE(KB)    WEIGHT\t WAIT         RUNTIME         SLEEP         VRUNTIME\n");
    printf(1, "-----------------------------------------------------------------------------------------------------------\n");

    for (int i = 0; i < n; i++) {
      struct uproc *p = &arr[i].p;
      int cpu_x10 = arr[i].cpu_x10;
      int whole = cpu_x10 / 10;
      int frac  = cpu_x10 % 10;
      int size_kb = (int)(p->sz / 1024);

      
      char namebuf[17];
      int j;
      for (j = 0; j < 16; j++) namebuf[j] = p->name[j];
      namebuf[16] = '\0';

      printf(1, "%d\t %s\t %s\t %d.%d\t     %d\t     %d\t          %d\t      %d\t      %d\t      %d\n",
             p->pid, state_name(p->state),namebuf, whole, frac,
             size_kb,p->weight,p->rnbletime,p->rtime,p->stime,p->vruntime);
    }
      
      printf(1, "\n[PRESS ENTER TO EXIT]\n");

      // Update State
      pn = n;
      for (i = 0; i < pn; i++) prev[i] = cur[i];
      first = 0;

      sleep(REFRESH_TICKS);
    }
  } 
  
  else {
    char buf[10];
    
    // This blocks until you press Enter. 
    // It consumes almost 0 CPU while waiting.
    read(0, buf, sizeof(buf));
    
    // User pressed enter: kill the child and exit
    kill(pid);
    wait();
    exit();
  }
}
