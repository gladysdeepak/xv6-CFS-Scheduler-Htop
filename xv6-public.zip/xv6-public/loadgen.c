#include "types.h"
#include "stat.h"
#include "user.h"

// CPU-intensive task
void cpu_task(int loops) {
    volatile int x = 0;
    for(int i = 0; i < loops; i++)
        x += i;
}

// IO-like task (sleep-based)
void io_task(int loops) {
    for(int i = 0; i < loops; i++)
        sleep(1);
}

// Mixed workload task
void mixed_task(int loops) {
    volatile int x = 0;
    for(int i = 0; i < loops; i++) {
        x += i;
        if((i % 5000000) == 0)
            sleep(1);
    }
}

int main(int argc, char *argv[]) {
    if(argc < 2) {
        printf(2, "Usage: loadgen <num>\n");
        exit();
    }

    int n = atoi(argv[1]);
    printf(1, "loadgen: creating %d processes\n", n);

    for(int i = 0; i < n; i++) {

        //printf(1, "Starting process %d...\n", i);

        int pid = fork();
        if(pid == 0) {
            // Child: pick a workload type
            while(1){
              if(i % 3 == 0)
                  cpu_task(100000000);
              else if(i % 3 == 1)
                  io_task(200);
              else
                  mixed_task(50000000);
            }
            //sleep(200);
            exit();
        }

        // Delay so htop can show each process appearing one by one
        sleep(20);
    }

    // Parent waits for all children
    while(wait() > 0);

    printf(1, "loadgen finished.\n");
    exit();
}

