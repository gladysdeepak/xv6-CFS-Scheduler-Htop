#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[])
{
  printf(1, "Starting CPU test...\n");

  // This volatile variable ensures the compiler doesn't optimize away our loop
  volatile unsigned long long i;

  // Running an infinitely long loop to consume CPU.
  for(i = 0; ; i++)
  {
  if(i%1000 == 0){}
  }

  exit();
}
